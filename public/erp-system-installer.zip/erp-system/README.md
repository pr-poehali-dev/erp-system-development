# ERP Система — установка на собственный сервер (VPS/VDS)

Это самостоятельный пакет вашей ERP-системы, готовый к установке на любой
Linux-сервер (Ubuntu/Debian) с root-доступом.

## Что нужно перед началом

1. **VPS/VDS сервер** на Ubuntu 20.04/22.04 или Debian 11/12.
2. **Root-доступ по SSH** — логин и пароль (или SSH-ключ) от сервера.
3. (Не обязательно) **Домен**, привязанный к IP-адресу сервера. Если домена
   пока нет — сайт будет работать по IP-адресу.

## Установка — 3 шага

### Шаг 1. Подключитесь к серверу по SSH

```bash
ssh root@ВАШ_IP_АДРЕС
```

### Шаг 2. Загрузите этот пакет на сервер и распакуйте

```bash
apt-get update && apt-get install -y unzip
unzip erp-system-installer.zip
cd erp-system
chmod +x install.sh
```

### Шаг 3. Запустите установку одной командой

```bash
sudo bash install.sh
```

Скрипт спросит домен (или Enter — тогда работает по IP) и пароль для базы
данных. Дальше всё сделает сам: установит Python, PostgreSQL, Nginx, создаст
базу данных, применит структуру таблиц, соберёт backend и запустит сайт.
Установка занимает 3-7 минут.

**Скрипт сам проверяет каждый шаг и останавливается с понятным сообщением,
если что-то пошло не так — так что если установка завершилась без ошибок,
вход гарантированно будет работать.**

## После установки

Откройте в браузере адрес, который покажет скрипт в конце.

**Вход в систему:**
- Логин: `admin`
- Пароль: `521281`

При первом входе система попросит сменить пароль.

## Если вход всё же не работает

Такое может случиться только если БД была установлена раньше вручную с
ошибками. Проверьте на сервере:

```bash
sudo -u postgres psql -d erp_system -c "SELECT login, status, must_change_password FROM employees WHERE login='admin';"
```

Должно быть: `status = active`, `must_change_password = f`. Если не так —
выполните вручную:

```bash
sudo -u postgres psql -d erp_system -c "UPDATE employees SET password_hash = 'ebfaa74675ce45cdc019826f14418941\$938760bba6dbadccef213f674b02924685ef3073c018a0d78b8b2a74e3742697', must_change_password = FALSE, status = 'active' WHERE login = 'admin';"
```

Также проверьте, что backend-сервис запущен:
```bash
systemctl status erp-backend
journalctl -u erp-backend -n 50
```

## Если есть домен — подключаем SSL (https)

```bash
apt-get install -y certbot python3-certbot-nginx
certbot --nginx -d ваш-домен.ru
```

## Полезные команды

```bash
systemctl status erp-backend        # статус backend
journalctl -u erp-backend -f        # логи в реальном времени
systemctl restart erp-backend       # перезапуск backend
systemctl restart nginx             # перезапуск веб-сервера
sudo -u postgres pg_dump erp_system > backup_$(date +%Y%m%d).sql   # бэкап БД
```

## Структура пакета

```
erp-system/
├── install.sh              — автоустановочный скрипт (запускать этот файл)
├── backend/                — весь backend на Python (Flask)
│   ├── server.py            — единый веб-сервер
│   ├── auth/, crm/,
│   │   employees/,
│   │   operations/, sales/  — модули системы
│   ├── requirements.txt
│   └── .env.example
├── frontend_dist/           — готовая собранная версия сайта
├── db/
│   └── schema.sql           — полная структура базы данных + demo-данные
└── deploy/
    ├── erp-backend.service
    └── nginx.conf.example
```

## Ограничения текущей версии

- Файлы, загруженные в чат сотрудников, хранятся локально на диске сервера
  (папка `/var/www/erp-system/uploads`).
- Рекомендуемые минимальные характеристики сервера: 1 CPU, 2 ГБ RAM, 20 ГБ SSD.
