"""
ERP System — единый Flask-сервер для обычного VPS.

Оборачивает 5 обработчиков (auth, crm, employees, operations, sales),
изначально написанных для serverless-функций (событие/контекст),
в один HTTP-сервер на Flask. Код самих обработчиков (index.py) НЕ менялся
по логике — только заменено облачное S3-хранилище на локальный диск (в crm/index.py).

Запуск для разработки:
    python3 server.py

Запуск в продакшене — через gunicorn (см. systemd unit в deploy/):
    gunicorn -w 4 -b 127.0.0.1:8000 server:app
"""
import importlib.util
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, request, Response, send_from_directory

load_dotenv(Path(__file__).resolve().parent / '.env')


def load_handler(module_name: str, file_path: Path):
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module.handler


BASE_DIR = Path(__file__).resolve().parent

HANDLERS = {
    'auth': load_handler('backend_auth', BASE_DIR / 'auth' / 'index.py'),
    'crm': load_handler('backend_crm', BASE_DIR / 'crm' / 'index.py'),
    'employees': load_handler('backend_employees', BASE_DIR / 'employees' / 'index.py'),
    'operations': load_handler('backend_operations', BASE_DIR / 'operations' / 'index.py'),
    'sales': load_handler('backend_sales', BASE_DIR / 'sales' / 'index.py'),
}

app = Flask(__name__)


class DummyContext:
    """Заглушка контекста serverless-функции (обработчики её не используют, но ожидают аргумент)."""
    request_id = 'local'


def make_event() -> dict:
    """Конвертирует Flask-запрос в формат event, который ожидают обработчики."""
    body = request.get_data(as_text=True) or ''
    headers = {k: v for k, v in request.headers.items()}
    return {
        'httpMethod': request.method,
        'queryStringParameters': request.args.to_dict(),
        'headers': headers,
        'body': body,
        'isBase64Encoded': False,
        'requestContext': {
            'identity': {'sourceIp': request.remote_addr or ''},
        },
    }


def dispatch(func_name: str):
    handler = HANDLERS[func_name]
    event = make_event()
    result = handler(event, DummyContext())
    status = result.get('statusCode', 200)
    resp_headers = result.get('headers', {})
    body = result.get('body', '')
    return Response(body, status=status, headers=resp_headers)


@app.route('/api/<func_name>', methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'])
def api_route(func_name):
    if func_name not in HANDLERS:
        return Response('{"error": "Неизвестная функция"}', status=404, content_type='application/json')
    return dispatch(func_name)


@app.route('/uploads/<path:filename>')
def uploads(filename):
    uploads_dir = os.environ.get('UPLOADS_DIR', '/var/www/erp-system/uploads')
    return send_from_directory(uploads_dir, filename)


@app.route('/health')
def health():
    return {'status': 'ok'}


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8000))
    app.run(host='0.0.0.0', port=port, debug=False)
