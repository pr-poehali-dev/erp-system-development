#!/bin/bash
# ============================================================
# ERP System — автоматическая установка на VPS/VDS (Ubuntu/Debian)
#
# Запускать от root на чистом сервере:
#   sudo bash install.sh
#
# Скрипт спросит: домен сайта и пароль для базы данных.
# Дальше всё сделает сам: установит Python, PostgreSQL, Nginx,
# создаст базу данных, применит схему, соберёт бэкенд-сервис,
# разложит фронтенд и запустит всё.
# ============================================================
set -e

if [ "$EUID" -ne 0 ]; then
  echo "Запустите скрипт от root: sudo bash install.sh"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="/var/www/erp-system"

echo "============================================================"
echo " ERP System — установка"
echo "============================================================"
read -rp "Введите домен сайта (например erp.mycompany.ru), либо оставьте пустым для установки по IP: " SITE_DOMAIN
read -rp "Придумайте пароль для базы данных PostgreSQL: " -s DB_PASSWORD
echo ""
DB_NAME="erp_system"
DB_USER="erp_user"

echo ""
echo "→ Обновляю список пакетов и ставлю зависимости (Python, PostgreSQL, Nginx)..."
apt-get update -qq
apt-get install -y -qq python3 python3-venv python3-pip postgresql postgresql-contrib nginx curl > /dev/null

echo "→ Создаю базу данных и пользователя PostgreSQL..."
sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='${DB_USER}'" | grep -q 1 || \
  sudo -u postgres psql -c "CREATE USER ${DB_USER} WITH PASSWORD '${DB_PASSWORD}';"
sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'" | grep -q 1 || \
  sudo -u postgres psql -c "CREATE DATABASE ${DB_NAME} OWNER ${DB_USER};"

echo "→ Применяю схему базы данных (таблицы + демо-данные)..."
PGPASSWORD="${DB_PASSWORD}" psql -h localhost -U "${DB_USER}" -d "${DB_NAME}" -f "${SCRIPT_DIR}/db/schema.sql" > /dev/null

echo "→ Копирую файлы приложения в ${APP_DIR}..."
mkdir -p "${APP_DIR}"
cp -r "${SCRIPT_DIR}/backend" "${APP_DIR}/backend"
mkdir -p "${APP_DIR}/frontend"
cp -r "${SCRIPT_DIR}/frontend_dist/"* "${APP_DIR}/frontend/"
mkdir -p "${APP_DIR}/uploads/chat"

PUBLIC_URL="http://${SITE_DOMAIN}"
if [ -z "$SITE_DOMAIN" ]; then
  SERVER_IP=$(curl -s ifconfig.me || echo "your-server-ip")
  SITE_DOMAIN="${SERVER_IP}"
  PUBLIC_URL="http://${SERVER_IP}"
fi

echo "→ Создаю файл настроек backend (.env)..."
cat > "${APP_DIR}/backend/.env" <<EOF
DATABASE_URL=postgresql://${DB_USER}:${DB_PASSWORD}@localhost:5432/${DB_NAME}
MAIN_DB_SCHEMA=public
PUBLIC_BASE_URL=${PUBLIC_URL}
UPLOADS_DIR=${APP_DIR}/uploads
PORT=8000
EOF

echo "→ Создаю виртуальное окружение Python и ставлю зависимости..."
python3 -m venv "${APP_DIR}/backend/venv"
"${APP_DIR}/backend/venv/bin/pip" install --quiet --upgrade pip
"${APP_DIR}/backend/venv/bin/pip" install --quiet -r "${APP_DIR}/backend/requirements.txt"

echo "→ Настраиваю права доступа..."
useradd -r -s /bin/false www-data 2>/dev/null || true
chown -R www-data:www-data "${APP_DIR}"

echo "→ Устанавливаю systemd-сервис для backend..."
cp "${SCRIPT_DIR}/deploy/erp-backend.service" /etc/systemd/system/erp-backend.service
systemctl daemon-reload
systemctl enable erp-backend > /dev/null
systemctl restart erp-backend

echo "→ Настраиваю Nginx..."
sed -e "s/ваш-домен.ru/${SITE_DOMAIN}/g" \
    -e "s|/var/www/erp-system|${APP_DIR}|g" \
    "${SCRIPT_DIR}/deploy/nginx.conf.example" > /etc/nginx/sites-available/erp-system
ln -sf /etc/nginx/sites-available/erp-system /etc/nginx/sites-enabled/erp-system
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl restart nginx

echo ""
echo "============================================================"
echo " Установка завершена!"
echo "============================================================"
echo ""
echo " Адрес сайта:       ${PUBLIC_URL}"
echo " Логин:              admin"
echo " Пароль:             521281"
echo " (при первом входе система попросит сменить пароль)"
echo ""
echo " Проверить статус backend:   systemctl status erp-backend"
echo " Логи backend:               journalctl -u erp-backend -f"
echo ""
if [ -n "$SITE_DOMAIN" ] && [[ "$SITE_DOMAIN" != *"."*"."*"."* ]]; then
  echo " Чтобы включить бесплатный SSL-сертификат после привязки домена,"
  echo " выполните:  apt-get install -y certbot python3-certbot-nginx && certbot --nginx -d ${SITE_DOMAIN}"
fi
echo "============================================================"
