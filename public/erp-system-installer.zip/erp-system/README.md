# ERP Система — установка на собственный сервер (VPS/VDS)

## Установка — 3 шага

### Шаг 1. Подключитесь к серверу по SSH
```bash
ssh root@ВАШ_IP_АДРЕС
```

### Шаг 2. Загрузите пакет и распакуйте
```bash
apt-get update && apt-get install -y unzip
unzip erp-system-installer.zip
cd erp-system
chmod +x install.sh
```

### Шаг 3. Запустите установку
```bash
sudo bash install.sh
```

Скрипт спросит домен (или Enter для установки по IP) и пароль для базы
данных. Дальше всё сделает сам и проверит каждый шаг: базу данных, backend,
проксирование через Nginx.

## Вход в систему

- Логин: `admin`
- Пароль: `521281`

## Если у вас уже установлена предыдущая версия и вход не работает

Причина была в том, что собранный фронтенд не мог правильно обратиться к
относительному адресу API. Обновите пакет:

```bash
cd /home/erp-system   # или туда, где лежит распакованный архив
unzip -o erp-system-installer.zip
cd erp-system
sudo cp -r frontend_dist/* /var/www/erp-system/frontend/
sudo systemctl restart erp-backend
sudo systemctl restart nginx
```

После этого обновите страницу в браузере (Ctrl+Shift+R, чтобы сбросить кэш).

## Диагностика проблем со входом

```bash
# 1. Backend отвечает напрямую?
curl -i http://127.0.0.1:8000/health

# 2. Nginx правильно проксирует /api/?
curl -i "http://localhost/api/auth?action=me"
# Ожидается код 401 (не авторизован) — это нормально, значит соединение работает

# 3. Проверка пользователя admin в базе
sudo -u postgres psql -d erp_system -c "SELECT login, status, must_change_password FROM employees WHERE login='admin';"
```

Если пункт 2 возвращает ошибку соединения — проблема в Nginx
(`nginx -t`, `systemctl status nginx`).
Если пункт 1 не отвечает — проблема в backend
(`systemctl status erp-backend`, `journalctl -u erp-backend -n 50`).

## Полезные команды

```bash
systemctl status erp-backend
journalctl -u erp-backend -f
systemctl restart erp-backend
systemctl restart nginx
sudo -u postgres pg_dump erp_system > backup_$(date +%Y%m%d).sql
```

## Структура пакета

```
erp-system/
├── install.sh
├── backend/
│   ├── server.py
│   ├── auth/, crm/, employees/, operations/, sales/
│   ├── requirements.txt
│   └── .env.example
├── frontend_dist/
├── db/schema.sql
└── deploy/
    ├── erp-backend.service
    └── nginx.conf.example
```
